import java.util.LinkedList;

class Customer {
    String name;
    int ticketNumber;

    public Customer(String name, int ticketNumber) {
        this.name = name;
        this.ticketNumber = ticketNumber;
    }

    @Override
    public String toString() {
        return "Customer: " + name + " - Ticket No: " + ticketNumber;
    }
}

class QueueManager {
    // Generic method to add customers to a LinkedList
    public static <T> void addToQueue(LinkedList<T> queue, T customer) {
        queue.add(customer);
        System.out.println(customer + " added to the queue.");
    }

    // Display all customers in the queue
    public static <T> void displayQueue(LinkedList<T> queue) {
        System.out.println("Queue: " + queue);
    }
}

public class LinkedListQueueApp {
    public static void main(String[] args) {
        LinkedList<Customer> customerQueue = new LinkedList<>();

        // Adding customers to the LinkedList queue
        QueueManager.addToQueue(customerQueue, new Customer("John Doe", 101));
        QueueManager.addToQueue(customerQueue, new Customer("Jane Smith", 102));

        // Displaying customers in the queue
        QueueManager.displayQueue(customerQueue);
    }
}