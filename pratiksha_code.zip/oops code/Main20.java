class Exam {
    protected String[] questions = {
        "1. What is the capital of India?",
        "2. 2 + 2 = ?",
        "3. Java is a _____ language."
    };
    
    protected String[] answers = {
        "Delhi", "4", "Object-Oriented"
    };

    public void startExam() {
        System.out.println("Exam started. Answer the following questions:");
    }
    
    public int checkAnswers(String[] userAnswers) {
        int score = 0;
        for (int i = 0; i < answers.length; i++) {
            if (answers[i].equalsIgnoreCase(userAnswers[i])) {
                score++;
            }
        }
        return score;
    }
}

class StudentExam extends Exam {
    private String studentName;

    public StudentExam(String name) {
        this.studentName = name;
    }

    @Override
    public void startExam() {
        super.startExam();
        Scanner scanner = new Scanner(System.in);
        String[] userAnswers = new String[questions.length];

        for (int i = 0; i < questions.length; i++) {
            System.out.println(questions[i]);
            userAnswers[i] = scanner.nextLine();
        }

        int score = checkAnswers(userAnswers);
        System.out.println(studentName + ", your score is: " + score + "/" + questions.length);
    }
}

public class OnlineExamApp {
    public static void main(String[] args) {
        StudentExam exam = new StudentExam("Pratishtha");
        exam.startExam();
    }
}
