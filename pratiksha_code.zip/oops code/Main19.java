import java.util.*;

class ListUtils {

    public static <T> void addElementToList(List<T> list, T element) {
        list.add(element);
        System.out.println("Added " + element + " to the list.");
    }
    public static <T> void displayList(List<T> list) {
        System.out.println("List elements: " + list);
    }
}

public class GenericListApp {
    public static void main(String[] args) {
       
        List<String> arrayList = new ArrayList<>();
        ListUtils.addElementToList(arrayList, "Java");
        ListUtils.addElementToList(arrayList, "Generics");
        ListUtils.displayList(arrayList);

      
        List<Integer> linkedList = new LinkedList<>();
        ListUtils.addElementToList(linkedList, 100);
        ListUtils.addElementToList(linkedList, 200);
        ListUtils.displayList(linkedList);
    }
}
